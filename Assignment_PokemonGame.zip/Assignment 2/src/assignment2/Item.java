package assignment2;

public class Item { //Simona
    private final String name;
    private final int healingPower;
    private final double weight;

    public Item(String name,int healingPower,double weight){
        this.name = name;
        this.healingPower = healingPower;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public int getHealingPower() {
        return healingPower;
    }

    public String toString(){
        String message;
        double truncateWeight = (int)(this.weight*100)/(double)100;

        message = String.format("%s heals %d HP. (%.2f)",this.name,this.healingPower, truncateWeight);

        return message;
    }

    @Override
    public boolean equals(Object anotherObject){
        boolean isEqual = false;
        if(anotherObject == this){
            isEqual = true;
        }else if(anotherObject == null){
            isEqual = false;
        }else if(anotherObject instanceof Item){
            Item anotherItem = (Item)anotherObject;
            boolean sameHealingPower = this.healingPower == anotherItem.healingPower;
            boolean sameName = this.name.equals(anotherItem.name);
            boolean sameWeight = this.weight ==  anotherItem.weight;

            isEqual = sameHealingPower && sameName && sameWeight;
        } else {
            isEqual = false;
        }
        return isEqual;
    }

}
