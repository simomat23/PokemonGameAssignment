package assignment2;

import java.util.ArrayList;

public class Pokemon {

    //Cazandra
    private String name;
    private final int MAX_HP;
    private int EP;
    private Type type;
    private int HP;
    final int MAX_EP = 100;
    private Skill skill;
    private ItemBag itemBag;

    final String END_OF_LINE = System.lineSeparator();

    public Pokemon(String name, int MAX_HP, String type){ //Cazandra

        this.name = name;
        this.MAX_HP = MAX_HP;
        this.HP = this.MAX_HP;
        this.skill = null;
        this.EP = MAX_EP;

        switch (type) {
            case "Fire" -> this.type = Type.FIRE;
            case "Water" -> this.type = Type.WATER;
            case "Grass" -> this.type = Type.GRASS;
            case "Normal" -> this.type = Type.NORMAL;
            case "Bug" -> this.type = Type.BUG;
            case "Dragon" -> this.type = Type.DRAGON;
            case "Electric" -> this.type = Type.ELECTRIC;
            case "Ice" -> this.type = Type.ICE;
        }

    }

    public double getEnergy(){
        return this.EP;
    }

    public double getCurrentHP(){
        return this.HP;
    }

    public double getMAX_HP(){
        return this.MAX_HP;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type.toString();
    }

    public void forgetSkill(){
        this.skill = null;
    }

    public void learnSkill(String name, int attackPower, int energyCost) {
        this.skill = new Skill(name, attackPower, energyCost);
    }


    public boolean knowsSkill(){
        boolean knowsSkill = false;
        if(this.skill != null){
            knowsSkill = true;
        }
        return knowsSkill;
    }

    //printing of the skill if assigned
    public String toString(){
        if(this.skill != null){
            return String.format("%s (%s). Knows %s - AP: %d EC: %d",getName(),getType(),skill.getName(),skill.getAP(),skill.getEC());
        }else{
            return String.format("%s (%s)",getName(), getType());
        }
    }

    //attacking
    public void receiveDamage(double damage) {
        this.HP = this.HP - (int)damage;

        if (this.HP <= 0) {
            this.HP = 0;

        }
    }

    public String attack(Pokemon pokemon1){

        //Seti

        //double damage
        boolean FireToGrass = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.GRASS);
        boolean WaterToFire = this.type.equals(Type.WATER) && pokemon1.type.equals(Type.FIRE);
        boolean GrassToWater = this.type.equals(Type.GRASS) && pokemon1.type.equals(Type.WATER);
        //new types
        boolean BugToGrass = this.type.equals(Type.BUG) && pokemon1.type.equals(Type.GRASS);
        boolean DragonToDragon = this.type.equals(Type.DRAGON) && pokemon1.type.equals(Type.DRAGON);
        boolean ElectricToWater = this.type.equals(Type.ELECTRIC) && pokemon1.type.equals(Type.WATER);
        boolean FireToBug = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.BUG);
        boolean FireToIce = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.ICE);
        boolean IceToDragon = this.type.equals(Type.ICE) && pokemon1.type.equals(Type.DRAGON);
        boolean IceToGrass = this.type.equals(Type.ICE) && pokemon1.type.equals(Type.GRASS);
        //half damage
        boolean FireToWater = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.WATER);
        boolean FireToFire = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.FIRE);
        boolean WaterToWater = this.type.equals(Type.WATER) && pokemon1.type.equals(Type.WATER);
        boolean GrassToFire = this.type.equals(Type.GRASS) && pokemon1.type.equals(Type.FIRE);
        boolean GrassToGrass = this.type.equals(Type.GRASS) && pokemon1.type.equals(Type.GRASS);
        boolean WaterToGrass = this.type.equals(Type.WATER) && pokemon1.type.equals(Type.GRASS);

        //new types
        boolean BugToFire = this.type.equals(Type.BUG) && pokemon1.type.equals(Type.FIRE);
        boolean ElectricToDragon = this.type.equals(Type.ELECTRIC) && pokemon1.type.equals(Type.DRAGON);
        boolean ElectricToElectric = this.type.equals(Type.ELECTRIC) && pokemon1.type.equals(Type.ELECTRIC);
        boolean ElectricToGrass = this.type.equals(Type.ELECTRIC) && pokemon1.type.equals(Type.GRASS);
        boolean FireToDragon = this.type.equals(Type.FIRE) && pokemon1.type.equals(Type.DRAGON);
        boolean GrassToBug = this.type.equals(Type.GRASS) && pokemon1.type.equals(Type.BUG);
        boolean GrassToDragon = this.type.equals(Type.GRASS) && pokemon1.type.equals(Type.DRAGON);
        boolean IceToFire = this.type.equals(Type.ICE) && pokemon1.type.equals(Type.FIRE);
        boolean IceToIce = this.type.equals(Type.ICE) && pokemon1.type.equals(Type.ICE);
        boolean IceToWater = this.type.equals(Type.ICE) && pokemon1.type.equals(Type.WATER);
        boolean WaterToDragon = this.type.equals(Type.WATER) && pokemon1.type.equals(Type.DRAGON);

        //Simona
        String message ="";

        //failed attacks
        if(this.HP == 0){

            message = "Attack failed. " + this.name + " fainted.";
        }else if(pokemon1.HP == 0){

            message = "Attack failed. " + pokemon1.name + " is fainted";
        }else if(this.skill == null){

            message = "Attack failed. " + this.name + " does not know a skill.";
        }else if(this.EP < skill.getEC()){

            message = "Attack failed. " + this.name + " lacks energy: " + this.EP + "/" + skill.getEC();
        }

        //successful attacks
        if(pokemon1.HP > 0) {
            assert this.skill != null;

            if (FireToGrass || WaterToFire || GrassToWater || BugToGrass || DragonToDragon || ElectricToWater || FireToBug || FireToIce || IceToDragon || IceToGrass) {
                pokemon1.receiveDamage(this.skill.getAP()*2);

                this.spendEnergy();

                message = this.name + " uses " + skill.getName() + " on " + pokemon1.name + ". It is super effective!" + END_OF_LINE + pokemon1.name + " has " + pokemon1.HP + " HP left.";
                if(pokemon1.HP == 0){
                    message += " " + pokemon1.name + " faints.";
                }

            } else if (FireToFire || FireToWater || WaterToGrass || WaterToWater || GrassToGrass || GrassToFire || BugToFire || ElectricToDragon || ElectricToElectric || ElectricToGrass || FireToDragon || GrassToBug || GrassToDragon || IceToFire || IceToIce || IceToWater || WaterToDragon) {
                pokemon1.receiveDamage(this.skill.getAP()*0.5);

                this.spendEnergy();

                message = this.name + " uses " + skill.getName() + " on " + pokemon1.name + ". It is not very effective..." + END_OF_LINE + pokemon1.name + " has " + pokemon1.HP + " HP left.";;
                if(pokemon1.HP == 0){
                    message += " " + pokemon1.name + " faints.";
                }

            }else {
                pokemon1.receiveDamage(this.skill.getAP());

                this.spendEnergy();

                message = this.name + " uses " + skill.getName() + " on " + pokemon1.name + "." + END_OF_LINE + pokemon1.name + " has " + pokemon1.HP + " HP left.";;
                if(pokemon1.HP == 0){
                    message += " " + pokemon1.name + " faints.";
                }

            }
        }else {
            assert this.skill != null;
            pokemon1.receiveDamage(this.skill.getAP());

                message = this.name + " uses " + skill.getName() + " on " + pokemon1.name + ". " + pokemon1.name + " faints.";

        }

        return message;
    }


    //gaining health back through resting
    public void rest(){  //Simona
        int HpResting = 20;
        if(this.HP > 0 && this.HP < MAX_HP){
            this.HP += HpResting;
        }else if(HP == MAX_HP){
            this.HP += 0;
        }else if(HP == 0){
            this.HP += 0;
        }
        if(this.HP > MAX_HP){
            this.HP = MAX_HP;
        }
    }

    //gaining energy back
    public void recoverEnergy(){ //Simona, Seti
        int EpRecovery = 25;
        if(this.HP > 0){
            this.EP += EpRecovery;
        }else{
            this.EP += 0;
        }
        if(this.EP > MAX_EP){
            this.EP = MAX_EP;
        }
    }

    public void spendEnergy(){ //Simona

        this.EP = this.EP - skill.getEC();
    }

    //using an Item

    public String useItem(Item item){ //Simona
        if(this.HP == this.MAX_HP){

            return String.format("%s could not use %s. HP is already full.",this.name,item.getName());
        }else if(this.HP + item.getHealingPower() >this.MAX_HP){
            int excessHP = (this.HP + item.getHealingPower()) - this.MAX_HP;

            this.HP = (this.HP + item.getHealingPower()) - excessHP;

            int actualHealed = item.getHealingPower() - excessHP;

            return String.format("%s used %s. It healed %d HP.",this.name,item.getName(),actualHealed);
        }else{
            this.HP = this.HP + item.getHealingPower();

            if(this.HP > this.MAX_HP){
                this.HP = this.MAX_HP;
            }

            return String.format("%s used %s. It healed %d HP.",this.name,item.getName(),item.getHealingPower());
        }

    }

    @Override
    public boolean equals(Object anotherObject){ //Cazandra
        boolean isEqual = false;
        if(anotherObject == this){
            isEqual = true;

        }else if(anotherObject == null){
            isEqual = false;

        }else if(anotherObject instanceof Pokemon){
            Pokemon anotherPokemon = (Pokemon)anotherObject;
            boolean sameName = this.name.equals(anotherPokemon.name);
            boolean sameMaxHP = this.MAX_HP == anotherPokemon.MAX_HP;
            boolean sameEP = this.EP == anotherPokemon.EP;
            boolean sameType = this.type ==  anotherPokemon.type;
            boolean sameHP = this.HP == anotherPokemon.HP;
            boolean sameSkill = this.skill == anotherPokemon.skill;

            isEqual = sameName && sameMaxHP && sameEP && sameType && sameHP && sameSkill;

        } else {
            isEqual = false;
        }
        return isEqual;
    }

}
