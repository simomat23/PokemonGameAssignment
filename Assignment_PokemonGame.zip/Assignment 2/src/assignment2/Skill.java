package assignment2;

public class Skill { //Cazandra

    private String name;
    private int AP;
    private int EC;

    public Skill (String name, int attackPower, int energyCost){
        this.name = name;
        this.AP = attackPower;
        this.EC = energyCost;
    }

    public String toString (){
        String printSkill;
        printSkill = name + " - AP: " + AP + " EC: " + EC;
        return printSkill;
    }

    public String getName() {
        return this.name;
    }

    public int getAP(){
        return this.AP;
    }

    public int getEC(){
        return this.EC;
    }

    public boolean equals(Object otherObject){
        boolean isEqual = false;
        if(otherObject == this){
            isEqual = true;

        }else if(otherObject == null){
            isEqual = false;

        }else if(otherObject instanceof Skill){
            Skill otherSkills = (Skill) otherObject;
            boolean sameName = this.name.equals(otherSkills.name);
            boolean sameAP = this.AP == otherSkills.AP;
            boolean sameEC = this.EC == otherSkills.EC;

            isEqual = sameName && sameAP && sameEC;

        }else{
            isEqual = false;

        }return isEqual;
    }


}
