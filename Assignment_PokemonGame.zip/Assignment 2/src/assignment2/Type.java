package assignment2;

public enum Type { //Seti
    FIRE("Fire"),
    WATER("Water"),
    GRASS("Grass"),
    NORMAL("Normal"),
    //new
    BUG("Bug"),
    DRAGON("Dragon"),
    ELECTRIC("Electric"),
    ICE("Ice");

    private final String TYPE_NAME;
    private Type(String TYPE_NAME){
        this.TYPE_NAME = TYPE_NAME;
    }

    public String toString(){
        return (String)TYPE_NAME;
    }

}
