package assignment2;

import java.util.ArrayList;
import java.util.Objects;


public class ItemBag { //Simona

    private final double maxWeight;
    private ArrayList<Item> collectionOfItems;
    private double currentWeight;

    public ItemBag(double maxWeight){
        this.maxWeight = maxWeight;
        this.collectionOfItems = new ArrayList<>();
        this.currentWeight = 0;
    }

    public int getNumOfItems() {
        return collectionOfItems.size();
    }
    public double getCurrentWeight() {
        return currentWeight;
    }
    public double getMaxWeight() {
        return maxWeight;
    }

    public int addItem(Item item){

        if(item.getWeight() + this.currentWeight > this.maxWeight){

            return -1;

        }else if(this.collectionOfItems.isEmpty()){

            this.collectionOfItems.add(0,item);
            this.currentWeight = this.currentWeight + item.getWeight();

            return this.collectionOfItems.indexOf(item);
        }else {
            for (int i = 0; i < this.collectionOfItems.size(); i++) {

                if (item.getWeight() > this.collectionOfItems.get(i).getWeight()) {
                    this.collectionOfItems.add(i, item);

                    this.currentWeight = this.currentWeight + item.getWeight();

                    return i;
                }
            }

            this.collectionOfItems.add(item);

            this.currentWeight = this.currentWeight + item.getWeight();

            return collectionOfItems.indexOf(item);
        }

        //return index;
    }

    public Item removeItemAt(int index){

        Item someItem;
        
        if(index < collectionOfItems.size()){

            someItem = this.collectionOfItems.get(index);
            this.currentWeight = this.currentWeight - collectionOfItems.get(index).getWeight();

            this.collectionOfItems.remove(index);

        } else {
            someItem = null;
        }

        return someItem;
    }

    public String peekItemAt(int index){
        String item;
        if (index < 0) {
            item = "";
        }else if(index < collectionOfItems.size()){
            item = this.collectionOfItems.get(index).toString();
        }else {
            item = "";
        }

        return item;
    }

    public Item popItem(){
        Item removeThis;

        if(!this.collectionOfItems.isEmpty()){
            removeThis = this.collectionOfItems.get(0);

            this.currentWeight = this.currentWeight - collectionOfItems.get(0).getWeight();

            this.collectionOfItems.remove(0);

        }else {

            removeThis = null;
        }

        return removeThis;
    }
}
